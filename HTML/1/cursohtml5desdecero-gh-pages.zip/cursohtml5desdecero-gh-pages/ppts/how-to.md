#How to

Para generar la documentación:

1. Generar la documentación en la carpeta raw/md/
2. Generar las slides: ```./build.sh```
3. Abrir las urls en: /raw/export/