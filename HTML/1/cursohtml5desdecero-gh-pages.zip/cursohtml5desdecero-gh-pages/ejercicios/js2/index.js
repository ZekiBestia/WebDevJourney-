'use strict';

/*
  Crear un bucle for que imprima los mensajes:

  Valor de i: 0
  Valor de i: 2
  ... hasta ...
  Valor de i: 9
*/



/*
  Crear un bucle for que imprima los mensajes: con números pares

  Valor de i: 0
  Valor de i: 2
  Valor de i: 4
  ... hasta ...
  Valor de i: 8
*/


/*
  Crear un bucle dentro de otro (anidados) que imprima

  Valor de i: 0
  Valor de j: 0
  
  Valor de i: 0
  Valor de j: 1
  
  Valor de i: 0
  Valor de j: 2
  
  ... hasta ...
  
  Valor de i: 9
  Valor de j: 9
*/


